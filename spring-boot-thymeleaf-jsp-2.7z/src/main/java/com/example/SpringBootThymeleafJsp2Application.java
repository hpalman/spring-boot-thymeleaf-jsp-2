package com.example;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootThymeleafJsp2Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootThymeleafJsp2Application.class, args);
	}

}
